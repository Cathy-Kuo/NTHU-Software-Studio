// Initialize Firebase
/// TODO 1: Change to your firebase config
///         1. New a Firebase project
///         2. Copy and paste firebase config below
var config = {
  apiKey: "AIzaSyBzqE6C0OtgSvBhM6DK3SBHV6XhFhSzctE",
    authDomain: "snoopy-7667a.firebaseapp.com",
    databaseURL: "https://snoopy-7667a.firebaseio.com",
    projectId: "snoopy-7667a",
    storageBucket: "snoopy-7667a.appspot.com",
    messagingSenderId: "289077820654",
    appId: "1:289077820654:web:e232c3b96d224d60"
};

firebase.initializeApp(config);